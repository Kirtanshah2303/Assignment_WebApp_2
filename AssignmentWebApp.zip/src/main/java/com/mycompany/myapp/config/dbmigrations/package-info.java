/**
 * MongoDB database migrations using Mongock.
 */
package com.mycompany.myapp.config.dbmigrations;
