/**
 * Spring Data JPA repositories.
 */
package com.mycompany.myapp.repository;
